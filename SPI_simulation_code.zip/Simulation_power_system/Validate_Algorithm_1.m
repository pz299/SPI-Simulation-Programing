%% %Validation of Algorithm 1 simulation results in manuscript.
load('model_based_SPI_Data.mat')
radius_ABK_save; %$\rho (A_i)$

radius_cbABK_save; %$\rho (\frac{\prod_{j=0}^{i}{c_{j}}}{b}A_{i})$

inv_radius_cbABK= 1 ./ radius_cbABK_save(2:end); % $\rho ^{-1}(\frac{\prod_{j=0}^{i}{c_{j}}}{b}A_{i+1})$

C_save;% $\frac{\prod_{j=0}^{i}{c_{j}}}{b}$
c_it_save; % $c _i$

kk0; %Stabilized control gain matrix found using the scaling technique.

max(abs(eig(A-B*kk0)));%Spectral radius of the stabilized control gain matrix found using the scaling technique.

figure(1)
plot(0:length(P_save)-1,P_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
ylim([-15,100])
xlim([0 length(P_save)])
xline(it0+1, '--' , 'FontSize', 12)
legend('$||P_{i}-P_{i-1}||$','Interpreter', 'latex', 'FontSize', 17)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 17)
grid on
set(gca, 'FontSize', 13)  


figure(2)
plot(0:length(K_save)-1,K_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
xline(it0+1, '--' , 'FontSize', 12)
xlim([0 length(P_save)])
ylim([-0.35,3.5])
legend('$||K_{i}-K_{i-1}||$','Interpreter', 'latex', 'FontSize', 17)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 17)
grid on
set(gca, 'FontSize', 13)  
