clc;clear;
T_g=0.08;
T_t=0.1;
T_p=20;
R_g=2.5;
K_p=120;
K_t=1;
T_s = 0.01; 
Ac=[-1/T_g 0 1/(R_g*T_g);
    K_t/T_t -1/T_t 0;
    0 K_p/T_p -1/T_p];
Bc=[0;1/T_g;0];
A = expm(Ac*T_s);
B = quadv(@(t)myFun(t,-Ac),0,T_s)*expm(Ac*T_s)*Bc; 
eig(A)
[xn,un]=size(B);
Q=1*eye(xn);
R=1;
x0=[0.1;0.1;0.2];
X=x0';
U=[];
opt_K =[ 0.4022    0.8351    1.2066];
for i=1:110
u=-zeros(un,xn)*x0;
x1=A*x0+B*u;
U=[U;u];
x0=x1;
X=[X;x0'];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%
x0=[0.1;0.1;0.2];
X1=x0';
U1=[];
for i1=1:20
u=-zeros(un,xn)*x0;
x1=A*x0+B*u;
U1=[U1;u];
x0=x1;
X1=[X1;x0'];
end
%%%%%%%%%%%%%%%%
for i2=21:110
u=-opt_K*x0;
x1=A*x0+B*u;
U1=[U1;u];
x0=x1;
X1=[X1;x0'];
end
%%
figure(1);
subplot(3, 1, 1);
plot(0:i2,X(:,1),'--',0:i2,X1(:,1),'Linewidth',1.2)
xline(20, '--', 'Color', 'k');
yline(0, '--', 'Color', 'k');
ylim([-0.1,0.6])
legend('Uncontrolled ','Controlled ','NumColumns',2,'FontSize', 10);
ylabel('$\Delta \bar{\alpha}$','Interpreter', 'latex','FontSize', 12.5)
xlabel('Time(s)')
xlim([0,110])
set(gca, 'FontSize', 10)  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(3, 1, 2);
plot(0:i2,X(:,2),'--',0:i2,X1(:,2),'Linewidth',1.2)
xline(20, '--', 'Color', 'k');
yline(0, '--', 'Color', 'k');
ylim([-0.2,0.45])
legend('Uncontrolled ','Controlled ','NumColumns',2,'FontSize', 10);
ylabel('$\Delta P_{m}$','Interpreter', 'latex','FontSize', 12.5)
xlabel('Time(s)')
xlim([0,110])
set(gca, 'FontSize', 10)  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(3, 1, 3);
plot(0:i2,X(:,3),'--',0:i2,X1(:,3),'Linewidth',1.2)
xline(20, '--', 'Color', 'k');
yline(0, '--', 'Color', 'k');
legend('Uncontrolled ','Controlled ','NumColumns',2,'FontSize', 10);
ylabel('$\Delta f_{G}$','Interpreter', 'latex','FontSize', 12.5)
xlabel('Time(s)')
ylim([-0.5,2])
xlim([0,110])
set(gca, 'FontSize', 10)  




