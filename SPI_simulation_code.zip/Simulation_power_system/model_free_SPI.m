%% 
clc;clear;
T_g=0.08;
T_t=0.1;
T_p=20;
R_g=2.5;
K_p=120;
K_t=1;
T_s = 0.01;
Ac=[-1/T_g 0 1/(R_g*T_g);
    K_t/T_t -1/T_t 0;
    0 K_p/T_p -1/T_p];
Bc=[0;1/T_g;0];
A = expm(Ac*T_s);
B = quadv(@(t)myFun(t,-Ac),0,T_s)*expm(Ac*T_s)*Bc;
eig(A)
[xn,un]=size(B);
Q=1*eye(xn);
R=1;
opt_P =[ 6.4599    3.2440    6.3364;
    3.2440    7.6499   10.1346;
    6.3364   10.1346   33.5195];
opt_K =[0.4022    0.8351    1.2066];
%%  %sampling
x0=[0.1;0.1;0.2];
K0=zeros(un,xn);% using to sampling
%%%%%%%%%%%%%%%%%
DDx=[];
DDx_0=[];
for i_n_0=1:xn
    for it_n_0=i_n_0:xn
        DDx_0=[DDx_0,x0(i_n_0)*x0(it_n_0)];
    end
end
DDx=DDx_0;
%%%%%%%%%%%%%%%%%%%%%%%%
Iux=[];
Ixx=[];
X=x0;
U=[];
du=[];
%%%%%%%%%%%%%%%%%%%%%%%
expl_noise_freq = (rand(un,100)-.5)*10;
for i=1:30
    u=-K0*x0+sum(sin(expl_noise_freq*i),2);
    x1=A*x0+B*u;
    U=[U;u];
     Ixx=[Ixx;kron(x0',x0')];
    Iux=[Iux;kron(u',x0')];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    DDx_0=[];
    for i_n_0=1:xn
        for it_n_0=i_n_0:xn
            DDx_0=[DDx_0,x1(i_n_0)*x1(it_n_0)];
        end
    end
    DDx=[DDx;DDx_0];
    %%%%%%%%%%%%%%%%
    du_0=[];
    for i_nu_0=1:un
        for it_u_0=i_nu_0:un
            du_0=[du_0,u(i_nu_0)*u(it_u_0)];
        end
    end
    du=[du;du_0];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    x0=x1;
    X=[X,x0];
end
Dx=DDx(2:end,:);
dx=DDx(1:end-1,:);
rank([Ixx,Iux,du])
%%  %The first loop of Algorithm 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
zhi_1=[];
K0=zeros(un,xn);
eig(A-B*K0)
b_save=[];
c=1;
b=1;
P0=-1*eye(xn);
K_save=[];
P_save=[];
svd_Q_it_save=[];%$\sigma \left( \mathcal{Q} _i \right) $
svd_PQ_it_save=[];%$\sigma (\widetilde{P}_{i}\mathcal{Q}_{i}^{-1})$
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
c_it_save=[];
Cb_save=1/b;%$\frac{1}{b}\prod_{j=0}^{i}{c_{j}}
rho_A_it_save=max(abs(eig(A-B*K0)));%$\rho \left( A-BK_i \right)$
n_irreversible=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
it_max=100
it=0
it_b=0;
it_c=0;
while it<100
    if  min(eig(P0))<0
        b=b+0.1;
        QK=Q+K0'*R*K0;
        KX=K0*X(:,1:(end-1));
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        d_kx=[];
        for n_kx=1:length(KX)
            kx=KX(:,n_kx);
            dkx_0=[];
            for i_nkx_0=1:un
                for it_nkx_0=i_nkx_0:un
                    dkx_0=[dkx_0,kx(i_nkx_0)*kx(it_nkx_0)];
                end
            end
            d_kx=[d_kx;dkx_0];
        end
        ThetA_01 =[(c^2/b^2)*Dx-dx,-2*(c^2/b^2)*Ixx*kron(K0',eye(xn))-2*(c^2/b^2)*Iux,(c^2/b^2)*d_kx-(c^2/b^2)*du];
        zhi_1=[zhi_1;rank(ThetA_01)];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%
        Pp=-pinv(ThetA_01)*Ixx*QK(:);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        vec_P= Pp(1:xn*(xn+1)/2);
        P1 = zeros(xn, xn);
        index = 1;
        for i = 1:xn
            for j = i:xn
                if i == j
                    P1(i,j) = vec_P(index);
                else
                    P1(i,j) = vec_P(index) / 2;
                    P1(j,i) = P1(i,j);
                end
                index = index + 1;
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                b_save=[b_save,b];
        it_b=it_b+1;
        P0=P1;
    else
                QK=Q+K0'*R*K0;
        KX=K0*X(:,1:(end-1));
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        d_kx=[];
        for n_kx=1:length(KX)
            kx=KX(:,n_kx);
            dkx_0=[];
            for i_nkx_0=1:un
                for it_nkx_0=i_nkx_0:un
                    dkx_0=[dkx_0,kx(i_nkx_0)*kx(it_nkx_0)];
                end
            end
            d_kx=[d_kx;dkx_0];
        end
        ThetA_02 =[(c^2/b^2)*Dx-dx,-2*(c^2/b^2)*Ixx*kron(K0',eye(xn))-2*(c^2/b^2)*Iux,(c^2/b^2)*d_kx-(c^2/b^2)*du];
        zhi_1=[zhi_1;rank(ThetA_02)];
        Pp=-pinv(ThetA_02)*Ixx*QK(:);
        vec_P= Pp(1:xn*(xn+1)/2);
        P1 = zeros(xn, xn);
        index = 1;
        for i = 1:xn
            for j = i:xn
                if i == j
                    P1(i,j) = vec_P(index);
                else
                    P1(i,j) = vec_P(index) / 2;
                    P1(j,i) = P1(i,j);
                end
                index = index + 1;
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        M=reshape(Pp((xn+1)*xn/2+1:(xn+1)*xn/2+xn*un),xn,un);
        L=Pp(end);
        K1=inv(L+(b^2/c^2)*R)*M';
        P_save=[P_save;norm(P0-P1)];
        K_save=[K_save;norm(K0-K1)];
        K0=K1;
        kk0=K0;
        P0=P1;
        rho_A_it_save=[rho_A_it_save,max(abs(eig(A-B*K0)))]; %$\rho \left( A-BK_i \right)$
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Q_it=P1-Q-K1'*R*K1;
        svd_Q_it_save=[svd_Q_it_save,min(svd(Q_it))];%$\sigma \left( \mathcal{Q} _i \right) $
        if min(eig(Q+K1'*R*K1-P1))==0
            n_irreversible=n_irreversible+1;
            c_it=1;
        else
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            pp_2= P1*inv(Q+K1'*R*K1-P1);
            c_it=1+((min(svds(pp_2)))^0.5-1)*rand;
            svd_PQ_it_save=[svd_PQ_it_save,min(svd(P1*inv(Q_it)))];%$\sigma (\widetilde{P}_{i}\mathcal{Q}_{i}^{-1})$

        end
        c_it_save=[c_it_save,c_it];
        c=c*c_it;
        Cb_save=[Cb_save,c/b];%$\frac{1}{b}\prod_{j=0}^{i}{c_{j}}
        it_c= it_c+1;
        it=it+1;
                if c/b>=1
            break
        end
    end
end
rho_ABK_stablie=max(abs(eig(A-B*kk0))); %Check the stability of the obtained control gain matrix K
% when the stopping condition is met
sqrt_svd_PQ_it = sqrt(svd_PQ_it_save);

%% model free to find the optimal solution
P0=0*eye(xn);
while   it<it_max
    it=it+1;
    P0=P1;
    QK=Q+K0'*R*K0;
    KX=K0*X(:,1:(end-1));
    d_kx=[];
    for n_kx=1:length(KX)
        kx=KX(:,n_kx);
        dkx_0=[];
        for i_nkx_0=1:un
            for it_nkx_0=i_nkx_0:un
                dkx_0=[dkx_0,kx(i_nkx_0)*kx(it_nkx_0)];
            end
        end
        d_kx=[d_kx;dkx_0];
    end
    ThetA =[Dx-dx,-2*Ixx*kron(K0',eye(xn))-2*Iux,d_kx-du];
    zhi_1=[zhi_1;rank(ThetA)];
    Pp=-pinv(ThetA)*Ixx*QK(:);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    vec_P= Pp(1:xn*(xn+1)/2);
    P1 = zeros(xn, xn);
    index = 1;
    for i = 1:xn
        for j = i:xn
            if i == j
                P1(i,j) = vec_P(index);
            else
                P1(i,j) = vec_P(index) / 2;
                P1(j,i) = P1(i,j);
            end
            index = index + 1;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    M=reshape(Pp((xn+1)*xn/2+1:(xn+1)*xn/2+xn*un),xn,un);
    L=Pp(end);
    K1=inv(L+R)*M';
    P_save=[P_save;norm(P1-P0)];
    K_save=[K_save;norm(K1-K0)];
    K0=K1;
    if norm(P1-P0)<10^(-5)
        break
    end
end
it
eig(A-B*K0)
norm(K1-opt_K)
norm(P1-opt_P)
%save('model_free_SPI_Data.mat');  

figure(1)
plot(1:length(P_save),P_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
xline(it_c+1, '--' , 'FontSize', 12)
legend('$||P_{i}-P_{i-1}||$','Interpreter', 'latex', 'FontSize', 17)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 17)
xlim([0 length(P_save)+1])
ylim([-2.5 max(P_save)+2.5])
grid on
set(gca, 'FontSize', 13)  

figure(2)
plot(1:length(K_save),K_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
xline(it_c+1, '--' , 'FontSize', 12)
legend('$||K_{i}-K_{i-1}||$','Interpreter', 'latex', 'FontSize', 14)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 14)
xlim([0 length(K_save)+1])
ylim([-0.1 max(K_save)+0.15])
grid on
set(gca, 'FontSize', 13)  
