%%  %Validation of Algorithm 2 simulation results in manuscript.
clc;clear;
load('model_free_SPI_Data.mat')

rho_A_it_save;%$\rho \left( A-BK_i \right)$

Cb_save=[1/b,Cb_save(2:end)];%$\frac{1}{b}\prod_{j=0}^{i}{c_{j}}

sqrt_svd_PQ_it;%$\sigma (\widetilde{P}_{i}\mathcal{Q}_{i}^{-1})^0.5$

c_it_save=[1,c_it_save];   %$c_{i}$

svd_Q_it_save;%$\sigma \left( \mathcal{Q} _i \right) $


figure(1)
plot(1:length(P_save),P_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
xline(it_c+1, '--' , 'FontSize', 12)
legend('$||P_{i}-P_{i-1}||$','Interpreter', 'latex', 'FontSize', 17)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 17)
xlim([0 length(P_save)+1])
ylim([-2.5 max(P_save)+2.5])
grid on
set(gca, 'FontSize', 13)  

figure(2)
plot(1:length(K_save),K_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
xline(it_c+1, '--' , 'FontSize', 12)
legend('$||K_{i}-K_{i-1}||$','Interpreter', 'latex', 'FontSize', 14)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 14)
xlim([0 length(K_save)+1])
ylim([-0.1 max(K_save)+0.15])
grid on
set(gca, 'FontSize', 13)  
