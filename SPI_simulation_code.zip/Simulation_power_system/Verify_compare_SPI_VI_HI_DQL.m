%%  % Verify the comparison simulation of model free SPI, VI, HI, and DQL algorithms.
clc;clear
load('compare_SPI_VI_HI_Q_data.mat')
SPI_time_mean;
SPI_it_mean;
VI_time_mean;
VI_it_mean;
HI_time_mean;
HI_it_mean;
Q_time_mean;
Q_it_mean;
