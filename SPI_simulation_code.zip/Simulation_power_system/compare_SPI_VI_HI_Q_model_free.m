%% 
clc;clear;
T_g=0.08;
T_t=0.1;
T_p=20;
R_g=2.5;
K_p=120;
K_t=1;
T_s = 0.01;
Ac=[-1/T_g 0 1/(R_g*T_g);
    K_t/T_t -1/T_t 0;
    0 K_p/T_p -1/T_p];
Bc=[0;1/T_g;0];
A = expm(Ac*T_s);
B = quadv(@(t)myFun(t,-Ac),0,T_s)*expm(Ac*T_s)*Bc;
eig(A)
[xn,un]=size(B);
Q=1*eye(xn);
R=1;
opt_P =[ 6.4599    3.2440    6.3364;
    3.2440    7.6499   10.1346;
    6.3364   10.1346   33.5195];
opt_K =[0.4022    0.8351    1.2066];



%% sample
x0=[0.1;0.1;0.2];
K0=zeros(un,xn);
%%%%%%%%%%%%%%%%%
DDx=[];
DDx_0=[];
for i_n_0=1:xn
    for it_n_0=i_n_0:xn
        DDx_0=[DDx_0,x0(i_n_0)*x0(it_n_0)];
    end
end
DDx=DDx_0;
%%%%%%%%%%%%%%%%%%%%%%%%
Iux=[];
Ixx=[];
Ixx_1=[];
X=x0;
U=[];
du=[];
Z_Q_original=[];
X_Q_original=x0;
%%%%%%%%%%%%%%%%%%%%%%%
expl_noise_freq = (rand(un,100)-.5)*10;
for i=1:30
    u=-K0*x0+sum(sin(expl_noise_freq*i),2);
    x1=A*x0+B*u;
    U=[U;u];
        Ixx=[Ixx;kron(x0',x0')];
    Iux=[Iux;kron(u',x0')];
    Ixx_1=[Ixx_1;kron(x1',x1')];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    DDx_0=[];
    for i_n_0=1:xn*(xn+1)+2*xn*un+un*(un+1)
        for it_n_0=i_n_0:xn
            DDx_0=[DDx_0,x1(i_n_0)*x1(it_n_0)];
        end
    end
    DDx=[DDx;DDx_0];
    %%%%%%%%%%%%%%%%
    dU_0=[];
    for i_nu_0=1:un
        for it_u_0=i_nu_0:un
            dU_0=[dU_0,u(i_nu_0)*u(it_u_0)];
        end
    end
    du=[du;dU_0];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     z=[x0;u];
    Z_Q_original=[Z_Q_original,z];
    X_Q_original=[X_Q_original,x1];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    x0=x1;
    X=[X,x0];
end
Dx=DDx(2:end,:);
dx=DDx(1:end-1,:);
rank([Ixx,Iux,du])
%%
SPI_time=[];
SPI_it=[];
 SPI_normk=[];
VI_time=[];
VI_it=[];
VI_normk=[];
HI_time=[];
HI_it=[];
HI_normk=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
q_all=100
for q=1:q_all
 pp_initial=randn(xn);
  P_initial= pp_initial'* pp_initial
    K_initial=inv(R+B'*P_initial*B)*B'*P_initial*A;
    %%  SPI
tic; % 开始计时
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P1_spi= P_initial;
K0_spi=K_initial;
c=1;
b=1;
P0_spi=-1*eye(xn);
K_spi_save=[];
P_spi_save=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n_irreversible=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
it_max=100
it_spi=0
it_b=0;
for it_spi=0:it_max
         QK=Q+K0_spi'*R*K0_spi;
        KX=K0_spi*X(:,1:(end-1));
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        d_kx=[];
        for n_kx=1:length(KX)
            kx=KX(:,n_kx);
            dkx_0=[];
            for i_nkx_0=1:un
                for it_nkx_0=i_nkx_0:un
                    dkx_0=[dkx_0,kx(i_nkx_0)*kx(it_nkx_0)];
                end
            end
            d_kx=[d_kx;dkx_0];
        end
        ThetA_spi =[(c^2/b^2)*Dx-dx,-2*(c^2/b^2)*Ixx*kron(K0_spi',eye(xn))-2*(c^2/b^2)*Iux,(c^2/b^2)*d_kx-(c^2/b^2)*du];
           %%%%%%%%%%%%%%%%%%%%%%%%%%%
        Pp_spi=-pinv(ThetA_spi)*Ixx*QK(:);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        vecs_P_spi= Pp_spi(1:xn*(xn+1)/2);
        P0_spi = zeros(xn, xn);
        index = 1;
        for i = 1:xn
            for j = i:xn
                if i == j
                    P0_spi(i,j) = vecs_P_spi(index);
                else
                    P0_spi(i,j) = vecs_P_spi(index) / 2;
                    P0_spi(j,i) = P0_spi(i,j);
                end
                index = index + 1;
            end
        end
        if  min(eig(P0_spi))<0
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         b=b+0.7*it_spi;
            it_b=it_b+1;
    else
        
        M_spi=reshape(Pp_spi((xn+1)*xn/2+1:(xn+1)*xn/2+xn*un),xn,un);
        L_spi=Pp_spi(end);
        K1_spi=inv(L_spi+(b^2/c^2)*R)*M_spi';
        P_spi_save=[P_spi_save,norm(P0_spi-opt_P)];
        K_spi_save=[K_spi_save;norm(K1_spi-opt_K)];
        K0_spi=K1_spi;
                       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if min(eig(Q+K1_spi'*R*K1_spi-P0_spi))==0
            n_irreversible=n_irreversible+1;
            cc_2=1;
        else
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            pp_spi= P0_spi*inv(Q+K1_spi'*R*K1_spi-P0_spi);
                        cc_2=1+((min(svds(pp_spi)))^0.5-1)*rand;
                                  end
               c=c*cc_2;
               it_c=it_spi;
        if c/b>=1
            break
        end
    end
end
%it_b

%% model free to find the optimal solution
while   it_spi<it_max
    it_spi=it_spi+1;
      QK=Q+K0_spi'*R*K0_spi;
    KX=K0_spi*X(:,1:(end-1));
    d_kx=[];
    for n_kx=1:length(KX)
        kx=KX(:,n_kx);
        dkx_0=[];
        for i_nkx_0=1:un
            for it_nkx_0=i_nkx_0:un
                dkx_0=[dkx_0,kx(i_nkx_0)*kx(it_nkx_0)];
            end
        end
        d_kx=[d_kx;dkx_0];
    end
    ThetA_spi =[Dx-dx,-2*Ixx*kron(K0_spi',eye(xn))-2*Iux,d_kx-du];
        Pp_spi=-pinv(ThetA_spi)*Ixx*QK(:);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    vecs_P= Pp_spi(1:xn*(xn+1)/2);
    P1_spi = zeros(xn, xn);
    index = 1;
    for i = 1:xn
        for j = i:xn
            if i == j
                P1_spi(i,j) = vecs_P(index);
            else
                P1_spi(i,j) = vecs_P(index) / 2;
                P1_spi(j,i) = P1_spi(i,j);
            end
            index = index + 1;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    M_spi=reshape(Pp_spi((xn+1)*xn/2+1:(xn+1)*xn/2+xn*un),xn,un);
    L_spi=Pp_spi(end);
    K1_spi=inv(L_spi+R)*M_spi';
    K0_spi=K1_spi;
        if norm(K1_spi-opt_K)<10^(-4)
        break
    end
    P0_spi=P1_spi;
end
spi_Time = toc;  
SPI_time=[SPI_time;spi_Time];
SPI_it=[SPI_it;it_spi];
SPI_normk=[SPI_normk;norm(K1_spi-opt_K)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% VI  model free to find the optimal solution
tic;
it_vi=0;
P0_vi=0*eye(xn);
P1_vi=P_initial;
K0_vi=K_initial;
while   norm(K0_vi-opt_K)>10^(-4) & it_vi<200
    it_vi=it_vi+1;
    P0_vi=P1_vi;
    QK=Ixx_1*P0_vi(:);
    ThetA_vi =[dx,2*Iux,du];
          Pp_vi=pinv(ThetA_vi)*QK(:);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    vecs_H1_vi= Pp_vi(1:xn*(xn+1)/2);
    H1_vi = zeros(xn, xn);  % A'PA
    index = 1;
    for i = 1:xn
        for j = i:xn
            if i == j
                H1_vi(i,j) = vecs_H1_vi(index);
            else
                H1_vi(i,j) = vecs_H1_vi(index) / 2;
                H1_vi(j,i) = H1_vi(i,j);
            end
            index = index + 1;
        end
    end
    H2_vi=reshape(Pp_vi(xn*(xn+1)/2+1:xn*(xn+1)/2+xn*un),xn,un);% A'PB
    H3_vi=Pp_vi(xn*(xn+1)/2+xn*un+1:end);  % B'PB
    K1_vi=inv(H3_vi+R)*H2_vi';
    K0_vi=K1_vi;
    P1_vi= H1_vi-H2_vi*inv(H3_vi+R)*H2_vi'+Q;
    end
vi_Time = toc; 
it_vi
VI_time=[VI_time;vi_Time];
VI_it=[VI_it;it_vi];
VI_normk=[VI_normk;norm(K1_vi-opt_K)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  HI
tic;
%% HI_1: VI model free to find the  admissible controller
it_Hi=0;
P0_hi_vi=-20*eye(xn);
P1_hi_vi=P_initial;
K0_hi_vi=K_initial;
p_HI_save=norm(P1_hi_vi-opt_P);
k_HI_save=norm(K0_hi_vi-opt_K);
Q1=1*Q+eye(xn);
while   max(eig(P1_hi_vi-P0_hi_vi-Q1))>0  & it_Hi<200
    it_Hi=it_Hi+1;
    P0_hi_vi=P1_hi_vi;
    QK_hi_vi=Ixx_1*P0_hi_vi(:);
    ThetA_hi_vi =[dx,2*Iux,du];
         Pp_hi_vi=pinv(ThetA_hi_vi)*QK_hi_vi(:);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    vec_Hi1_vi= Pp_hi_vi(1:xn*(xn+1)/2);
    Hi1_vi = zeros(xn, xn);
    index = 1;
    for i = 1:xn
        for j = i:xn
            if i == j
                Hi1_vi(i,j) = vec_Hi1_vi(index);
            else
                Hi1_vi(i,j) = vec_Hi1_vi(index) / 2;
                Hi1_vi(j,i) = Hi1_vi(i,j);
            end
            index = index + 1;
        end
    end
    Hi2_vi=reshape(Pp_hi_vi(xn*(xn+1)/2+1:xn*(xn+1)/2+xn*un),xn,un);% A'PB
    Hi3_vi=Pp_hi_vi(end);  % B'PB
    K1_hi_vi=inv(Hi3_vi+R)*Hi2_vi';
    P1_hi_vi= Hi1_vi-Hi2_vi*inv(Hi3_vi+R)*Hi2_vi'+Q1;
    end
it_hi_vi=it_Hi;
%% HI_2: PI model free to find the optimal solution
P1_hi_pi=P1_hi_vi;
K0_hi_pi=K1_hi_vi;
P0_hi_pi=0*eye(xn);
while   norm(K0_hi_pi-opt_K)>10^(-4) & it_Hi<200
    it_Hi=it_Hi+1;
    P0_hi_pi=P1_hi_pi;
    QK_hi_vi=Q+K0_hi_pi'*R*K0_hi_pi;
    KX=K0_hi_pi*X(:,1:(end-1));
    d_kx=[];
    for n_kx=1:length(KX)
        d_kx=[d_kx;KX(n_kx)*KX(n_kx)];
    end
    ThetA_hi_pi =[Dx-dx,-2*Ixx*kron(K0_hi_pi',eye(xn))-2*Iux,d_kx-du];
        Pp_hi_vi=-pinv(ThetA_hi_pi)*Ixx*QK_hi_vi(:);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    vecs_P1_hi_pi= Pp_hi_vi(1:xn*(xn+1)/2);
    P1_hi_pi = zeros(xn, xn);
    index = 1;
    for i = 1:xn
        for j = i:xn
            if i == j
                P1_hi_pi(i,j) = vecs_P1_hi_pi(index);
            else
                P1_hi_pi(i,j) = vecs_P1_hi_pi(index) / 2;
                P1_hi_pi(j,i) = P1_hi_pi(i,j);
            end
            index = index + 1;
        end
    end

    M_hi=reshape(Pp_hi_vi((xn+1)*xn/2+1:(xn+1)*xn/2+xn*un),xn,un);
    L_hi=Pp_hi_vi(end);
    K1_hi_pi=inv(L_hi+R)*M_hi';
    K0_hi_pi=K1_hi_pi;
    end
hi_Time = toc; 
it_Hi
it_hi_vi
HI_time=[HI_time;hi_Time];
HI_it=[HI_it;it_Hi];
HI_normk=[HI_normk;norm(K1_hi_pi-opt_K)];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%  Q
Q_time=[];
Q_it=[];
Q_normk=[];
for n=1:q_all
tic; % 开始计时
h0x=X_Q_original(:,1:end-1);
h1x=X_Q_original(:,2:end);
h0u=U';
    n = size(h0x,1);
    m = size(h0u,1);
    N = size(h0x,2);
        F = pinv(h0x);
    G = null(h0x);
    Abar=h1x*F;
    Bbar=h1x*G;
     rankB=rank(Bbar,1e-4);
    BF=zeros(n,rankB);
    BF(:,1)=Bbar(:,1);
    rankBF=rank(BF,1e-4);
    ind=ones(rankB,1);
    count=1; j=2;
    while count<rankB
        BF(:,count+1)=Bbar(:,j);
        rankB2=rank(BF,1e-4);
        if rankB2>rankBF
            count=count+1;
            ind(count)=j;
            rankBF=rankB2;
        end
        j=j+1;
    end
    [Tr,Ac,Bc]=mi_ctrb(Abar,BF);    
    bl_ind=n*ones(rankB,1);
    for j=1:rankB-1
        for k=1:n
            if Bc(bl_ind(end-j+1)-k,rankB-j)>0.9
                bl_ind(end-j)=bl_ind(end-j+1)-k;
                break;
            end
        end
    end
    Hc_temp=Ac(bl_ind,:);
    C_Lue=Bc(bl_ind,:);
    Hc=C_Lue^-1*Hc_temp;    
    HF=Hc*Tr;               
    Hbar=zeros(size(G,2),n);
    Hbar(ind,:)=HF;           
    KDB=-h0u*(F-G*Hbar);
 K0_Q=KDB;

%%
r = rank(Z_Q_original);
[~, independent_cols_idx] = rref(Z_Q_original);
independent_cols_Z = Z_Q_original(:, independent_cols_idx);
independent_cols_X= X_Q_original(:, independent_cols_idx+1);
Z_Q= independent_cols_Z(:, 1:xn+un);
X_Q=independent_cols_X(:,1:xn+un);
q_it=0;
M_Q=rand*eye(xn+un);
 M0_Q=0*eye(xn+un);
QQ=[Q zeros(xn,un)
    zeros(un,xn) R];
K_Q=K0_Q;
while norm(K_Q-opt_K)>10^(-4) & q_it<100
    q_it=q_it+1;
    M0_Q=M_Q;
    F=[eye(xn);-K_Q];
    Xx=F*X_Q;
       M_Q=dlyap(Xx',Z_Q'*QQ*Z_Q,[],Z_Q'); 
    M_Q=(M_Q'+M_Q)/2;
    Muu=M_Q(xn+1:end,xn+1:end);
    Mux=M_Q(xn+1:end,1:xn);
    K_Q=inv(Muu)*Mux;
        end
q_Time = toc; 
Q_time=[Q_time;q_Time];
Q_it=[Q_it;q_it];
Q_normk=[Q_normk;norm(K_Q-opt_K)];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
SPI_time_mean=mean(SPI_time);
SPI_it_mean=mean(SPI_it);
SPI_normk_mean=mean(SPI_normk);
VI_time_mean=mean(VI_time);
VI_it_mean=mean(VI_it);
VI_normk_mean=mean(VI_normk);
HI_time_mean=mean(HI_time);
HI_it_mean=mean(HI_it);
HI_normk_mean=mean(HI_normk);
Q_time_mean= mean(Q_time);
Q_it_mean=mean(Q_it);
Q_normk_mean=mean(Q_normk);
%save('compare_SPI_VI_HI_Q_data.mat');


