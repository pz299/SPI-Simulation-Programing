function y=myFun(t,x)
  y=expm(x*t)
  end