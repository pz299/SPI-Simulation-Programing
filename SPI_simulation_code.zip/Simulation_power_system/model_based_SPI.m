clc;clear;
T_g=0.08;
T_t=0.1;
T_p=20;
R_g=2.5;
K_p=120;
K_t=1;
T_s = 0.01; 
Ac=[-1/T_g 0 1/(R_g*T_g);
    K_t/T_t -1/T_t 0;
    0 K_p/T_p -1/T_p];
Bc=[0;1/T_g;0];
A = expm(Ac*T_s);
B = quadv(@(t)myFun(t,-Ac),0,T_s)*expm(Ac*T_s)*Bc; 
eig(A)
[xn,un]=size(B);
Q=1*eye(xn);
R=1;
K0=zeros(un,xn);
eig(A-B*K0)
%%
b=max(abs(eig(A-B*K0)))+1;
P1=1*eye(xn);
P0=0*eye(xn);
c=1;
it=0;
c_it_save=1;
radius_cbABK_save=c/b*max(abs(eig(A-B*K0)));
radius_ABK_save=max(abs(eig(A-B*K0)));
C_save=c/b;
cc_inv=[];
K_save=[];
P_save=[];
it_max=100;
for it=0:it_max
    if c/b<1
      P0=P1;
f=@(P1)+(c/b)^2*(A-B*K0)'*P1*(A-B*K0)-P1+Q+K0'*R*K0;
P1=fsolve(f,P1);
P1=(P1+P1')/2;
K1=inv(B'*P1*B+b^2/c^2*R)*B'*P1*A;
K_save=[K_save,norm(K1-K0)];
P_save=[P_save,norm(P1-P0)];
K0=K1;
kk0=K1; %Record the stabilizing control gain matrix \( K \) found using the scaling technique.
it0=it;  %Record the number of iterations of the scaling technique.
radius_ABK_save=[radius_ABK_save,max(abs(eig(A-B*K1)))]; %$\rho (A_i)$
radius_cbABK_save=[radius_cbABK_save,c/b*max(abs(eig(A-B*K1)))]; %$\rho (\frac{\prod_{j=0}^{i}{c_{j}}}{b}A_{i})$
cc=max(c/b*abs(eig(A-B*K1)));
 c_it=1+((cc)^(-1)-1)*rand;
c_it_save=[c_it_save,c_it]; % $c _i$
c=c*c_it;
C_save=[C_save,c/b];% $\frac{\prod_{j=0}^{i}{c_{j}}}{b}$
    else
        b=1;
        c=1;
        P0=P1;
f=@(P1)+(c/b)^2*(A-B*K0)'*P1*(A-B*K0)-P1+Q+K0'*R*K0;
P1=fsolve(f,P1);
P1=(P1+P1')/2;
K1=inv(B'*P1*B+b^2/c^2*R)*B'*P1*A;
K_save=[K_save,norm(K1-K0)];
P_save=[P_save,norm(P1-P0)];
K0=K1;
if norm(P1-P0)<10^(-5)
    opt_P=P1;
opt_K=K0;
break
end
    end
end

%  [P,K]=dare(A,B,Q,R)
%  KK=inv(B'*P*B+R)*B'*P*A;
it
abs(eig(A-B*kk0))
it0
%save('model_based_SPI_Data.mat');  % 保存所有变量

inv_radius_cbABK= 1 ./ radius_cbABK_save; % $\rho ^{-1}(\frac{\prod_{j=0}^{i}{c_{j}}}{b}A_{i+1})$


figure(1)
plot(0:length(P_save)-1,P_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
%ylim([-15,100])
ylim([-0.1*max(P_save),max(P_save)+0.1*max(P_save)])
xlim([0 length(P_save)])
xline(it0+1, '--' , 'FontSize', 12)
legend('$||P_{i}-P_{i-1}||$','Interpreter', 'latex', 'FontSize', 17)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 17)
grid on
set(gca, 'FontSize', 13)  


figure(2)
plot(0:length(K_save)-1,K_save,'-o','LineWidth', 1.6,'MarkerSize', 8)
xline(it0+1, '--' , 'FontSize', 12)
xlim([0 length(P_save)])
ylim([-0.1*max(K_save),max(K_save)+0.1*max(K_save)])
legend('$||K_{i}-K_{i-1}||$','Interpreter', 'latex', 'FontSize', 17)
xlabel('Iteration number $i$','Interpreter', 'latex','FontSize', 17)
grid on
set(gca, 'FontSize', 13)  



